# The solver class is responsible for quite a few things. To put that in list
# from is:
#  + Draw the initial GUI elements
#  + Read file-input and call TSP for parsing
#  + Display status messages (so the user knows what's going on)
#  + Call TSP for solve
#  + Draw the results (and manage all drawing elements)
#  + Call TSP to get the total calcualte cost
class Solver

  # Initialize the application with the instance of Shoes (the
  # GUI object.
  def initialize(app)
    @app = app
  end

  # Draw the initial fields required to get this thing a-going.
  # basically just the file-select and a text-box.
  def draw
    @app.button 'Open TSP File', :width => '100%' do
      file = @app.ask_open_file
      if file
        do_computation(file)
      else
        @app.alert('No file selected')
      end
    end
    @note = @app.para('Open a TSP file to get started.')
  end

  def do_computation(file)
    (@drawn_objects ||= []).each {|o| o.remove }
    file_contents = File.open(file).read

    @note.replace('Parsing...')
    @tsp_data = ::TSP.parse(file_contents)

    @note.replace('Solving...')

    Thread.new do
      results = ::TSP.solve(@tsp_data)
      
      @note.replace("Solved.  Time Taken: #{results[:time]}ms")
      draw_graphs(results[:solutions])
    end
  end


  # Given a set of solution paths, draw all of the graphs to represent
  # the algorithmic evolution of the solution.
  #
  # paths - set of all paths in evolutionary chain
  #
  # Returns nothing. Just draws stuff.
  def draw_graphs(paths)
    @app.flow do
      @app.stack do
        paths.each_with_index do |path, i|
          @app.para "Solution #{i}. Cost #{TSP.path_cost(path)}"
          @app.image 300, 200 do
            draw_graph(path)
          end
        end
      end
    end
  end


  # Given a single path, draw it to the image object-block that
  # the method was called within.
  def draw_graph(path)
    coords = path.map {|node| draw_node(node) }

    coords.each_slice(2) {|s| draw_edge(s.first, s.last)}
    coords.unshift coords.pop
    coords.each_slice(2) {|s| draw_edge(s.first, s.last)}
    draw_edge(coords.first, coords.last) if coords.count.odd?
  end

  # draw the edges onto the Window given the edges (detailing which
  # nodes are connected) and the original tsp_data (which contains
  # the coordinate values and what not).
  #
  # n1 - Node object in which to draw a path 'from'
  # n2 - Node object in which to draw a path 'to'
  def draw_edge(c1, c2)
    return unless c1 && c2
    @app.line(c1[:x], c1[:y], c2[:x], c2[:y])
  end


  # Draw a node on the Window. (First need to scale it down)
  def draw_node(n)
    @padding ||= {
      top:      10,
      left:     10
    }
    @width  ||= 280
    @height ||= 180

    coords = {
      x: (n.x / max_x) * @width + @padding[:left],
      y: (n.y / max_y) * @height + @padding[:top]
    }
    
    @app.oval( left: coords[:x], top: coords[:y], radius: 4)
    coords
  end

  # Return the max X value for all nodes in the set
  def max_x
    @max_x ||= @tsp_data.map{|n| n.x}.max
  end

  # Return the max Y value for all nodes in the set
  def max_y
    @max_y ||= @tsp_data.map{|n| n.y}.max
  end
end
