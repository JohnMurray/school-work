require 'node'

# Contains all of the utility functions for processing and solving the
# travelling salesman problem. Currently none of the solutions require
# any type of data-structure outside of hashes and arrays, so this is
# bascially a grouping of methods at the moment.
module TSP
  TSP_REGEX = /^(?<point>\d+)\s+(?<coord1>\d+(\.\d+)?)\s+(?<coord2>\d+(\.\d+)?)/
  TSP_MUTATION_RATE = 0.05

  # Parse the *.tsp file into an Hash where the key is the point and 
  # the value is the location of the point.
  #
  # input_file  => A string (not a file-descriptor)
  # 
  # The value is in the format of:
  #   { x: c1, y: c2 }
  # Yes, I am assuming a 2-dimensional space
  def self.parse( input_file )
    points = []

    lines = input_file.split( "\n" )
    lines.each do |line|
      match = TSP_REGEX.match( line )
      if match
        points << Node.new({
          :name => match[:point].to_i,
          :x    => match[:coord1].to_f,
          :y    => match[:coord2].to_f
        })
      end
    end

    points
  end


  # A generic method to solve the problem that keeps track
  # of transitions and execution times.
  #
  # data - output from 'parse' method
  #
  # Returns a Hash in the following form:
  #   {
  #     solutions:    [Array of Arrays] solution for each generation,
  #     time:         [Integer] solve-time in milliseconds
  #   }
  def self.solve(data)
    results = {
      solutions: [],
      time:      0.0
    }

    results[:time] = t do
      population  = []
      100.times{ population << data.shuffle }

      # perform the evolutions
      100.times do |i|
        top_50 = population.sort {|a,b| path_cost(a) <=> path_cost(b) }

        # record the best solution
        results[:solutions] << top_50.first

        # split top-50 into pairs (mates)
        pairs = top_50.each_slice(2).to_a

        # breed/cross-select each pair
        pairs.each {|p| population.push(*cross_select_1(p[0], p[1])) if p.size == 2 }

        # Sort the population (now contains 150 solutions
        population.sort! {|a,b| path_cost(a) <=> path_cost(b) }

        # We only care about the top 100
        population = population[0...100]

        Shoes.p "eveolution ##{i} done"
      end

      # record the final best solution
      results[:solutions] << population.first
    end

    results
  end


  # Cross Selection (breeding) of both paths by maintaining a portion from
  # one parent. The idea is that the portion could be effecient so we'd like to
  # copy an entire portion from one parent and inject it into the other.
  #
  # path_* - path being used for parent (1 or 2)
  # repeat - If true, swap parents and do again (to produce second child)
  #
  # Returns a one or two-element array containing [a] solution(s) (an Array of
  # Node objects)
  def self.cross_select_1(path_1, path_2, repeat = true)
    p1 = path_1.dup
    p2 = path_2.dup

    sub_selection = p1[0..(p1.length/2)]
    sub_selection.each {|i| p2.delete i }

    p2.insert(p2.index(p1[p1.length/2+1]), *sub_selection)

    cross = p2
    reverse_cross = cross_select_1(path_2, path_1, false) if repeat

    [cross, reverse_cross].compact.map(&:flatten).map {|p| mutate(p) }
  end


  # Cross Selection (breeding) of both parents by maintaining node-pairs.
  # The idea is that if an efficient solution exists, then the path between
  # two adjacent nodes is effecient. So, let's choose one parent and maintain
  # all of their pairs when breeding with the second parent. The thing to note
  # is that the order of the pairs may differ in the resultant child.
  #
  # path_* - path being used for parent (1 or 2)
  # repeat - If true, swap parents and do again (to produce second child)
  # 
  # Returns a one or two-element array containing [a] solution(s) (an Array of
  # Node objects
  def self.cross_select_2(path_1, path_2, repeat = true)
    p1 = path_1.dup
    p2 = path_2.dup

    pairs = p1.each_slice(2).reject {|p| p.length != 2}

    pairs.each {|p| p2.delete p.last }
    pairs.each {|p| p2.insert(p2.index(p.first)+1, p.last)}

    cross = p2
    reverse_cross = cross_select_2(path_2, path_1, false) if repeat

    [cross, reverse_cross].compact.map(&:flatten).map {|p| mutate(p) }
  end

  # Mutate a path with probability equal to TSP_MUTATION_RATE
  #
  # path - Array of Node objects (the solution-path)
  #
  # Returns the path (possibly altered [mutated])
  def self.mutate(path)
    # called by cross_select function when breeding
    if rand <= TSP_MUTATION_RATE
     item = path.sample
     i    = path.index(item)

     next_i = i == 0 ? 1 : i - 1

     path[i], path[next_i] = path[next_i], path[i]
    end
    path
  end


  # Record the time of any block (executed immediately, so no worries
  # about closure-issues). 
  #
  # Returns the time that the block took to execute (in milliseconds)
  def self.t(&block)
    t1 = Time.now
    yield
    t2 = Time.now
    
    (t2 - t1) * 1_000
  end



  # Calculate the total cost of nodes in a population
  def self.path_cost(nodes)
    cost = 0
    nodes.each_with_index do |n, i|
      next_n = nodes[i+1] || nodes[0]
      cost += n.distance_to(next_n)
    end
    cost
  end

end
