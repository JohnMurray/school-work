require 'fiber'
require './tsp'


# Run the program from the Command Line. This works a little
# different than the GUI version in that we are using Ruby's
# Fibers. These are essentially co-routines in which we can
# run an iteration in the solve method and then yeild values
# to the calling code as they are ready. 
#
# This makes for a way in which a "dynamic" GUI could be
# elequently implemented. That is, if the GUI application I am
# using (Shoes) didn't package, and use, their own Ruby binaries
# which do not support Fibers correctly!
def main
  filename = ARGV[0]
  raise 'must provide TSP file as argument' unless filename

  100.times do |iteration|
    file = File.open(filename).read
    data = TSP.parse(file)

    fiber = Fiber.new { TSP.solve(data) }

    record_file = File.open('results.csv', 'a')

    generation = 1
    while fiber.alive? do
    	population = nil
    	time = TSP.t do
    	  population = fiber.resume
    	end
    	cost = TSP.path_cost(population)

      record_file.puts "#{generation},#{time},#{cost}"
      generation += 1
    end

    record_file.close
    puts "Finished Iteration ##{iteration}"
  end
end


main if $0 == __FILE__
